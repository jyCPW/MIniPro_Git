﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public float MHP = 100;
    public float HP = 100;

    public static GameManager thisManager;
    // Start is called before the first frame update
    void Start()
    {
        thisManager = this;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void UpdateHP()
    {
        HP -= 5;
        if(HP <= 0)
        {
            SceneManager.LoadScene("GameOver");
        }
    }
}
