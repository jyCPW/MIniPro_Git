﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public static Player thisPlayer;

    public float MHP = 100;
    public float HP = 100;
    public int Ammo = 100;
    public float movespeed = 6;
    public float Rotatespeed = 30;
    public float Enemycount = 0;
    // Start is called before the first frame update
    void Start()
    {
        thisPlayer = this;
    }

    private void Moveplayer()
    {
        float VerticalInput = Input.GetAxis("Vertical");
        float HorizontalInput = Input.GetAxis("Horizontal");
        Vector3 movedirection = new Vector3(HorizontalInput, 0, VerticalInput);
        transform.position += movedirection * Time.deltaTime * movespeed;
        float totalMovementInput = Mathf.Abs(VerticalInput) + Mathf.Abs(HorizontalInput);
    }

    private void RotatetoMousePosition()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
       
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit))
        {
           
            Vector3 TargetDirection = hit.point - transform.position;

            
            TargetDirection.y = 0;

            
            Quaternion TargetRotation = Quaternion.LookRotation(TargetDirection);


            transform.rotation = Quaternion.Slerp(transform.rotation, TargetRotation, Rotatespeed * Time.deltaTime);
            
        }
    }

    private void Shoot()
    {

    }



    // Update is called once per frame
    void Update()
    {
        RotatetoMousePosition();
        Moveplayer();
        
    }
}
