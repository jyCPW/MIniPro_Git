﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public float MHP = 100;
    public float HP = 100;
    public float Level;
    public Text Level_Txt;


    public static GameManager thisManager;
    // Start is called before the first frame update
    void Start()
    {
        thisManager = this;
        if(Level == 1)
        {
            Level_Txt.text = "Level: " + Level;
        }

        if(Level == 2)
        {
           
            Level_Txt.text = "Level: " + Level;
        }
    }

    // Update is called once per frame
    void Update()
    {
        
        if(Level == 1)
        {
            if (Player.thisPlayer.Enemycount <= 0)
            {
                SceneManager.LoadScene("Level 2");
            }
        }
        if(Level == 2)
        {
            if (Player.thisPlayer.Enemycount <= 0)
            {
                SceneManager.LoadScene("GameWin");
            }
        }
       
        
    }

    public void UpdateHP()
    {
        HP -= 5;
        if(HP <= 0)
        {
            SceneManager.LoadScene("GameOver");
        }
    }
}
