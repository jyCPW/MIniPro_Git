﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyM : MonoBehaviour
{
    public static EnemyM EnemyScript;
    [SerializeField]private float Speed = 5;
    [SerializeField] private float HP = 10;
    [SerializeField] private float AggroDist = 20;
    [SerializeField] private float ShootDist = 10;
    [SerializeField] public GameObject Bullet;
    private Transform target;
    public float Firerate = 0.25f;
    public float NextFire = 0f;
    private float Delay = 0;

    private NavMeshAgent theAgent = null;
    // Start is called before the first frame update
    void Start()
    {
        if (GameObject.FindGameObjectWithTag("Player") != null)
            target = GameObject.FindGameObjectWithTag("Player").transform;
        EnemyScript = this;
        theAgent = GetComponent<NavMeshAgent>();
        theAgent.speed = Speed;
    }

    // Update is called once per frame
    void Update()
    {
        if(Player.thisPlayer != null && Time.time >= Delay)
        {
            float Distance = Vector3.Distance(transform.position, Player.thisPlayer.transform.position);
            if(Distance <= AggroDist)
            {

                theAgent.speed = 5;
                theAgent.destination = Player.thisPlayer.transform.position;
            }
            if(Distance <= ShootDist)
            {
                theAgent.speed = 0;
                transform.LookAt(Player.thisPlayer.transform.position);
                enemyshoot();
            }
           
        }

         
    }
    public void Damaged()
    {
        HP--;
        if(HP <= 0)
        {
            
            Destroy(gameObject);
            Player.thisPlayer.Enemycount--;
        }
    }

    private void enemyshoot()
    {
        if(Time.time >= NextFire)
        {
            NextFire = Time.time + 1;

            Vector3 spawnPos = new Vector3(transform.position.x, transform.position.y + 0, transform.position.z);
            Instantiate(Bullet, spawnPos + Vector3.forward, transform.rotation);
        }
    }
}
