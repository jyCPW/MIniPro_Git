﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyM : MonoBehaviour
{
    public static EnemyM EnemyScript;
    [SerializeField]private float Speed = 10;
    [SerializeField] private float HP = 10;
    [SerializeField] private float AggroDist = 20;
    private float Delay = 0;

    private NavMeshAgent theAgent = null;
    // Start is called before the first frame update
    void Start()
    {
        EnemyScript = this;
        theAgent = GetComponent<NavMeshAgent>();
        theAgent.speed = Speed;
    }

    // Update is called once per frame
    void Update()
    {
        if(Player.thisPlayer != null && Time.time >= Delay)
        {
            float Distance = Vector3.Distance(transform.position, Player.thisPlayer.transform.position);
            if(Distance <= AggroDist)
            {
                if (theAgent.isStopped)
                {
                    theAgent.isStopped = false;
                    theAgent.destination = Player.thisPlayer.transform.position;
                }
            }
            else
            {theAgent.isStopped = true;}
         }

         
    }
    public void Damaged()
    {
        HP--;
        if(HP <= 0)
        {
            theAgent.isStopped = true;
            Destroy(gameObject);
            Player.thisPlayer.Enemycount--;
        }
    }
}
