﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraCon : MonoBehaviour
{
    public Vector3 Offset = Vector3.zero; 
    private Transform Target = null;
    // Start is called before the first frame update
    void Start()
    {
        if (GameObject.FindGameObjectWithTag("Player") != null)
            Target = GameObject.FindGameObjectWithTag("Player").transform;
        else
            Debug.Log("No player to assign");
    }

    // Update is called once per frame
    void Update()
    {
        if(Target != null)
        {
            transform.position = Target.position + Offset;
        }
    }
}
