﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public static UIManager OUIManager;
    public Image HPBar;
    public Image AmmoBar;
    // Start is called before the first frame update
    void Start()
    {
        OUIManager = this;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void UpdateHP(float HP)
    {
        float Width = HP * 3;
        HPBar.rectTransform.sizeDelta = new Vector2(Width, 30);
    }
    public void AmmoUPdate(float Ammo)
    {
        float Width = Ammo * 3;
        AmmoBar.rectTransform.sizeDelta = new Vector2(Width, 30);
    }
}
